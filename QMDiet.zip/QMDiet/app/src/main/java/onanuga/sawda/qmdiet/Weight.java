package onanuga.sawda.qmdiet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Weight extends AppCompatActivity {
    //reference to the GUI components
    private EditText rep1,rep2,rep3,rep4,rep5 ;
    private EditText weight1,weight2,weight3,weight4, weight5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
        rep1 = (EditText) findViewById(R.id.etRep);
        rep2 = (EditText) findViewById(R.id.etRep1);
        rep3 = (EditText) findViewById(R.id.etRep2);
        rep4 = (EditText) findViewById(R.id.etRep3);
        rep5 = (EditText) findViewById(R.id.etRep4);
        weight1 = (EditText) findViewById(R.id.etWeight);
        weight2 = (EditText) findViewById(R.id.etWeight2);
        weight3 = (EditText) findViewById(R.id.etWeight3);
        weight4 = (EditText) findViewById(R.id.etWeight4);
        weight5 = (EditText) findViewById(R.id.etWeight5);



    }
    public double inputWeight()//method returns whats inside the fields
    {
        int[] rgReps = new int[5];
        double[] rgWeight = new double[5];

        rgReps[0]= Integer.parseInt(rep1.getText().toString());
        rgReps[1]= Integer.parseInt(rep2.getText().toString());
        rgReps[2]= Integer.parseInt(rep3.getText().toString());
        rgReps[3]= Integer.parseInt(rep4.getText().toString());
        rgReps[4]= Integer.parseInt(rep5.getText().toString());

        rgWeight[0]= Double.parseDouble(weight1.getText().toString());
        rgWeight[1]= Double.parseDouble(weight2.getText().toString());
        rgWeight[2]= Double.parseDouble(weight3.getText().toString());
        rgWeight[3]= Double.parseDouble(weight4.getText().toString());
        rgWeight[4]= Double.parseDouble(weight5.getText().toString());
        double total =0;
        for(int i = 0;i<5;i++)
        {
            total +=  caloriesBurnt(rgReps[i], rgWeight[i]);
        }
    return total;
    }
    public double caloriesBurnt(int reps, double weight)
    {
        double cal;
        cal = reps * weight;
        return cal;
    }
}
